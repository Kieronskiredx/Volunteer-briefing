import type React from "react"

export default function VolunteerBriefing() {
  return (
    <main className="px-4 py-5">
      <h2 className="text-lg font-bold text-[#5C747A] mb-4">Volunteer briefing</h2>
      <h1 className="text-3xl font-bold text-[#262626] mb-4">Birmingham Airport Response</h1>
      <p className="text-sm text-[#262626] mb-6">
        The information in this briefing is specific to this deployment. For broader advice on responding effectively,
        use the Volunteer Playbook.
      </p>

      <div className="bg-gray-100 p-4 rounded-lg mb-6">
        <h3 className="text-xl font-semibold mb-4">Summary</h3>
        <p className="text-lg text-[#000000] mb-4">
          Reception centre for people displaced by conflict in Isle of Wight
        </p>
      </div>

      <Section title="Location">
        <InfoItem title="Address:" content="Terminal 2, Birmingham Airport, B15 9JK" />
        <InfoItem title="What3words:" content="verse.nerve.sober" />
        <InfoItem title="Meeting point:" content="Terminal 2, next to WH Smith" />
        <InfoItem
          title="Getting there:"
          content="train to Birmingham International Rail; car to BHX Premium Set-down (put note in windscreen)"
        />
        <InfoItem title="Hazards:" content="traffic on M42, take A452 if possible" />
      </Section>

      <Section title="Your shift and team">
        <InfoItem title="Start:" content="0815, Monday 25 February 2025" />
        <InfoItem title="End:" content="1325, Monday 25 February 2025" />
        <InfoItem title="OTL name and number:" content="Mark Wahlberg, 07987 555 421" />
        <InfoItem title="Duty Manager name and number:" content="Charlene Spiteri, 07773 468 231" />
        <InfoItem
          title="Partner liaison name and number:"
          content="Gary Sobers, Birmingham City Council, 07808 468 231"
        />
      </Section>

      <Section title="Deployment details">
        <InfoItem title="Forecast demand:" content="300 people affected, estimated 75 service users" />
        <InfoItem title="What to bring:" content="Personal water bottle" />
        <InfoItem title="Anticipated needs:" content="Emotional and psychosocial support, cash assistance" />
        <InfoItem
          title="Special assistance:"
          content="Local authority says 3 people arriving at 1030 use wheelchairs"
        />
        <InfoItem
          title="Risks and escalation:"
          content="If numbers of service users increase above 50, call Crisis Hub"
        />
        <InfoItem
          title="Equipment or supplies:"
          content="Birmingham City Council providing all rest centre kit; Tesco to provide water and cold food for 100 people, expected 1100, Monday 25 Feb"
        />
        <InfoItem
          title="Sensitivities:"
          content="It's considered offensive to call people from the Isle of Wight 'Wighties'"
        />
      </Section>
    </main>
  )
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="mb-6">
      <h3 className="text-xl font-bold text-[#262626] mb-4">{title}</h3>
      <div className="space-y-4">{children}</div>
    </div>
  )
}

function InfoItem({ title, content }: { title: string; content: string }) {
  return (
    <div className="text-base text-[#000000]">
      <span className="font-semibold">{title}</span> {content}
    </div>
  )
}

