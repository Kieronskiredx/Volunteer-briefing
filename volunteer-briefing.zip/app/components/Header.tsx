import { Menu } from "lucide-react"

export default function Header() {
  return (
    <header className="flex items-center justify-between h-16 px-4 border-b border-gray-200">
      <div className="flex items-center">
        <svg className="w-10 h-10 text-red-600" viewBox="0 0 40 40" fill="currentColor">
          <rect width="10" height="40" />
          <rect x="15" y="13" width="25" height="14" />
        </svg>
      </div>
      <button className="flex flex-col items-center justify-center w-16 h-16 border-l border-gray-200">
        <Menu className="w-6 h-6 text-gray-800" />
        <span className="text-xs text-gray-800 mt-1">MENU</span>
      </button>
    </header>
  )
}

