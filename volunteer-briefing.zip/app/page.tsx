import Header from "./components/Header"
import VolunteerBriefing from "./components/VolunteerBriefing"

export default function Home() {
  return (
    <div className="w-full max-w-[390px] mx-auto bg-white min-h-screen">
      <Header />
      <VolunteerBriefing />
    </div>
  )
}

